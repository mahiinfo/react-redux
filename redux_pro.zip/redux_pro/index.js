// import redux from 'redux';
const redux =require('redux')
const createStore = redux.createStore
const combineReducers =redux.combineReducers
const reduxLogger = require('redux-logger')
const applyMiddleware =redux.applyMiddleware
const logger = reduxLogger.createLogger()

const BUY_CAKE ='BUY_CAKE'
const BUY_ICECREAM ='BUY_ICECREAM'

// .... Action ..... //
function buyCake(){
    return{
        type :BUY_CAKE,
        info :'1st app'
    }
}
function buyIceCream(){
    return{
        type :BUY_ICECREAM,
        info :'2st app'
    }
}
// (previousState,action)=>newState

const intialState={
    numOfCakes:10,
    numberOfIce:10
}
const cake={
    numOfCakes:10,
   
}
const icecream={
   
    numberOfIce:10
}

//........ single reducer .......//

// const reducers =(state =intialState,action)=>{
//     switch(action.type){
//         case BUY_CAKE:return{
//             ...state,
//             numOfCakes :state.numOfCakes - 1
//         }
//         case BUY_ICECREAM:return{
            
//             ...state,
//             numberOfIce:state.numberOfIce - 1
        
//         }

//         default: return state
//     }

// }

// ..... dual reducer .....//
const cakeReducer =(state =cake,action)=>{
    switch(action.type){
        case BUY_CAKE:return{
            ...state,
            numOfCakes :state.numOfCakes - 1
        }
         default: return state
    }

}

const icecreamReducer =(state =icecream,action)=>{
    switch(action.type){
       
        case BUY_ICECREAM:return{
            
            ...state,
            numberOfIce:state.numberOfIce - 1
        
        }

        default: return state
    }

}

const rootReducer =combineReducers({
    cake:cakeReducer,
    icecream:icecreamReducer
})

const store = createStore(rootReducer,applyMiddleware(logger))
console.log('initial State',store.getState())
const unsubcribe = store.subscribe(()=>console.log('update state',store.getState()))
store.dispatch(buyCake())
store.dispatch(buyIceCream())
unsubcribe()

